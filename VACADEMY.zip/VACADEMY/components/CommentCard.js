import { View, Text } from 'react-native'
import React from 'react'

const CommentCard = () => {
  return (
    <View>
      <Text>CommentCard</Text>
    </View>
  )
}

export default CommentCard