import { View, Text, Image } from 'react-native'
import React from 'react'
import * as Icons from 'react-native-heroicons/outline';

const MockCard = (props) => {
  return (
    <View className="mt-2">
      <Text>MockCard</Text>
    </View>
  )
}

export default MockCard