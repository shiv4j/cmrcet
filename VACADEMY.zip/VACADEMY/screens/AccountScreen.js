import { View, Text } from 'react-native'
import React from 'react'

const AccountScreen = () => {
  return (
    <View>
      <Text>AccountScreen</Text>
    </View>
  )
}

export default AccountScreen